package com.order;

public interface BuyerOrderInterface {
	void SelectBuyerorder();
}
