package com.order;

public class Buyers implements BuyerOrderInterface{
	
	public void SelectBuyerorder() {
		
	}
	
}
